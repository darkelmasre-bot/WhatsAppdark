
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "9108866506:AAH0Twt6gbhUbvdKYi3N5K-_GyEPHqqSVEs" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "- 𝑰𝑻𝑺 »𝑺𝑨𝑺𝑨 CRASH BOT»࿅ 𓈪" //your bot name
global.OWNER_NAME = "https://t.me/X_9_X_9_9" //your name with sign @
global.OWNER = ["https://t.me/X_9_X_9_9", "https://t.me/X_9_X_9_9"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["8878714467"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://files.catbox.moe/ztcirt.png' //your bot pp


//approval
global.GROUP_ID = -1004476409613; // Replace with your group ID
global.CHANNEL_ID =  -1003329540749; // Replace with your channel ID
global.GROUP_LINK =" https://t.me/SASAxvip"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/X_9_X_9_9"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://wa.me/201109797436"; // Replace with your group link
global.YOUTUBE_LINK = "https://youtube.com/"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://whatsapp.com/"; // Replace with your ig link

global.owner = global.owner = ['+201109797436'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})